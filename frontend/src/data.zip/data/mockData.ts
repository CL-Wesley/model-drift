import { Dataset, ModelInfo, DriftAnalysisResults, DataPoint } from '../types';

// Mock reference dataset
export const mockReferenceData: DataPoint[] = [
    { age: 35, income: 50000, credit_score: 720, loan_amount: 15000, region: 'North', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 42, income: 75000, credit_score: 680, loan_amount: 25000, region: 'South', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 28, income: 45000, credit_score: 750, loan_amount: 12000, region: 'East', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 55, income: 90000, credit_score: 640, loan_amount: 35000, region: 'West', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 31, income: 55000, credit_score: 710, loan_amount: 18000, region: 'North', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 47, income: 82000, credit_score: 690, loan_amount: 28000, region: 'South', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 39, income: 65000, credit_score: 730, loan_amount: 22000, region: 'East', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 26, income: 38000, credit_score: 680, loan_amount: 10000, region: 'West', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 52, income: 95000, credit_score: 720, loan_amount: 40000, region: 'North', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 33, income: 58000, credit_score: 700, loan_amount: 20000, region: 'South', product_type: 'Basic', customer_segment: 'SMB' }
];

// Mock current dataset (with intentional drift)
export const mockCurrentData: DataPoint[] = [
    { age: 38, income: 55000, credit_score: 650, loan_amount: 18000, region: 'North', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 45, income: 80000, credit_score: 620, loan_amount: 30000, region: 'South', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 31, income: 50000, credit_score: 680, loan_amount: 15000, region: 'East', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 58, income: 95000, credit_score: 590, loan_amount: 42000, region: 'West', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 34, income: 60000, credit_score: 640, loan_amount: 21000, region: 'North', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 50, income: 87000, credit_score: 610, loan_amount: 33000, region: 'South', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 42, income: 70000, credit_score: 660, loan_amount: 26000, region: 'East', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 29, income: 43000, credit_score: 630, loan_amount: 13000, region: 'West', product_type: 'Basic', customer_segment: 'SMB' },
    { age: 55, income: 100000, credit_score: 650, loan_amount: 45000, region: 'North', product_type: 'Premium', customer_segment: 'Enterprise' },
    { age: 36, income: 63000, credit_score: 620, loan_amount: 24000, region: 'South', product_type: 'Basic', customer_segment: 'SMB' }
];

export const mockReferenceDataset: Dataset = {
    id: 'ref-dataset-001',
    name: 'Reference Dataset - Q1 2024',
    rows: mockReferenceData.length,
    columns: ['age', 'income', 'credit_score', 'loan_amount', 'region', 'product_type', 'customer_segment'],
    dataTypes: {
        age: 'integer',
        income: 'integer',
        credit_score: 'integer',
        loan_amount: 'integer',
        region: 'categorical',
        product_type: 'categorical',
        customer_segment: 'categorical'
    },
    uploadDate: new Date('2024-01-15'),
    size: 2048,
    preview: mockReferenceData.slice(0, 5)
};

export const mockCurrentDataset: Dataset = {
    id: 'curr-dataset-001',
    name: 'Current Dataset - Q3 2024',
    rows: mockCurrentData.length,
    columns: ['age', 'income', 'credit_score', 'loan_amount', 'region', 'product_type', 'customer_segment'],
    dataTypes: {
        age: 'integer',
        income: 'integer',
        credit_score: 'integer',
        loan_amount: 'integer',
        region: 'categorical',
        product_type: 'categorical',
        customer_segment: 'categorical'
    },
    uploadDate: new Date('2024-09-01'),
    size: 2156,
    preview: mockCurrentData.slice(0, 5)
};

export const mockModelInfo: ModelInfo = {
    id: 'model-001',
    name: 'Credit Risk Model v2.1',
    type: 'Random Forest Classifier',
    features: ['age', 'income', 'credit_score', 'loan_amount', 'region'],
    accuracy: 0.85,
    created_date: '2024-01-15',
    feature_importance: {
        credit_score: 0.35,
        income: 0.28,
        loan_amount: 0.20,
        age: 0.12,
        region: 0.05
    },
    format: 'pkl',
    size: 15728640
};

export const mockDriftResults: DriftAnalysisResults = {
    id: 'analysis-001',
    overall_drift_score: 1.8,
    overall_status: 'medium',
    total_features: 5,
    high_drift_features: 1,
    medium_drift_features: 2,
    low_drift_features: 2,
    data_quality_score: 0.92,
    model_compatibility_status: 'warning',
    analysis_timestamp: new Date(),
    feature_analysis: [
        {
            feature: 'credit_score',
            drift_score: 2.5,
            status: 'high',
            kl_divergence: 0.15,
            psi: 0.25,
            ks_statistic: 0.18,
            p_value: 0.001,
            data_type: 'numerical',
            missing_values_ref: 0,
            missing_values_current: 0,
            distribution_ref: {
                mean: 704,
                std: 28.5,
                min: 640,
                max: 750,
                q25: 685,
                q50: 705,
                q75: 725,
                histogram: [
                    { bin_start: 640, bin_end: 660, count: 1, frequency: 0.1 },
                    { bin_start: 660, bin_end: 680, count: 2, frequency: 0.2 },
                    { bin_start: 680, bin_end: 700, count: 2, frequency: 0.2 },
                    { bin_start: 700, bin_end: 720, count: 3, frequency: 0.3 },
                    { bin_start: 720, bin_end: 740, count: 1, frequency: 0.1 },
                    { bin_start: 740, bin_end: 760, count: 1, frequency: 0.1 }
                ]
            },
            distribution_current: {
                mean: 641,
                std: 25.2,
                min: 590,
                max: 680,
                q25: 620,
                q50: 640,
                q75: 660,
                histogram: [
                    { bin_start: 590, bin_end: 610, count: 1, frequency: 0.1 },
                    { bin_start: 610, bin_end: 630, count: 3, frequency: 0.3 },
                    { bin_start: 630, bin_end: 650, count: 4, frequency: 0.4 },
                    { bin_start: 650, bin_end: 670, count: 2, frequency: 0.2 },
                    { bin_start: 670, bin_end: 690, count: 0, frequency: 0.0 },
                    { bin_start: 690, bin_end: 710, count: 0, frequency: 0.0 }
                ]
            }
        },
        {
            feature: 'income',
            drift_score: 1.2,
            status: 'medium',
            kl_divergence: 0.08,
            psi: 0.12,
            ks_statistic: 0.09,
            p_value: 0.05,
            data_type: 'numerical',
            missing_values_ref: 0,
            missing_values_current: 0,
            distribution_ref: {
                mean: 65300,
                std: 18900,
                min: 38000,
                max: 95000,
                q25: 52500,
                q50: 62500,
                q75: 78750
            },
            distribution_current: {
                mean: 67800,
                std: 19200,
                min: 43000,
                max: 100000,
                q25: 55000,
                q50: 66500,
                q75: 83500
            }
        },
        {
            feature: 'age',
            drift_score: 0.8,
            status: 'low',
            kl_divergence: 0.04,
            psi: 0.06,
            ks_statistic: 0.05,
            p_value: 0.15,
            data_type: 'numerical',
            missing_values_ref: 0,
            missing_values_current: 0,
            distribution_ref: {
                mean: 38.8,
                std: 9.2,
                min: 26,
                max: 55,
                q25: 32,
                q50: 37,
                q75: 46
            },
            distribution_current: {
                mean: 41.2,
                std: 9.8,
                min: 29,
                max: 58,
                q25: 35,
                q50: 40,
                q75: 49
            }
        },
        {
            feature: 'loan_amount',
            drift_score: 1.5,
            status: 'medium',
            kl_divergence: 0.10,
            psi: 0.15,
            ks_statistic: 0.12,
            p_value: 0.02,
            data_type: 'numerical',
            missing_values_ref: 0,
            missing_values_current: 0,
            distribution_ref: {
                mean: 22500,
                std: 9200,
                min: 10000,
                max: 40000,
                q25: 15750,
                q50: 21000,
                q75: 27000
            },
            distribution_current: {
                mean: 25700,
                std: 10800,
                min: 13000,
                max: 45000,
                q25: 18000,
                q50: 24000,
                q75: 32250
            }
        },
        {
            feature: 'region',
            drift_score: 0.6,
            status: 'low',
            kl_divergence: 0.03,
            psi: 0.04,
            ks_statistic: 0.08,
            p_value: 0.25,
            data_type: 'categorical',
            missing_values_ref: 0,
            missing_values_current: 0,
            distribution_ref: {
                categories: [
                    { category: 'North', count: 3, frequency: 0.3 },
                    { category: 'South', count: 3, frequency: 0.3 },
                    { category: 'East', count: 2, frequency: 0.2 },
                    { category: 'West', count: 2, frequency: 0.2 }
                ]
            },
            distribution_current: {
                categories: [
                    { category: 'North', count: 3, frequency: 0.3 },
                    { category: 'South', count: 3, frequency: 0.3 },
                    { category: 'East', count: 2, frequency: 0.2 },
                    { category: 'West', count: 2, frequency: 0.2 }
                ]
            }
        }
    ],
    recommendations: [
        'Credit score shows significant drift - investigate scoring model changes',
        'Income distribution has shifted higher - validate against market trends',
        'Consider retraining model with recent data to maintain performance',
        'Monitor loan amount trends for business impact assessment'
    ],
    executive_summary: 'Analysis shows medium-level drift primarily driven by credit score degradation and income inflation. The model performance may be impacted and retraining should be considered within the next quarter.'
};
